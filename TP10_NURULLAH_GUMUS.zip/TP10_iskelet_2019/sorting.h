/*
 * sorting.h
 *
 *  Created on: Apr 19, 2019
 *      Author: Merve Unlu
 */

#ifndef SORTING_H_
#define SORTING_H_

void insertion_sort(int* arritem,int size);
void selection_sort(int* arritem,int size);
void bubble_sort(int* arritem,int size);

#endif /* SORTING_H_ */
