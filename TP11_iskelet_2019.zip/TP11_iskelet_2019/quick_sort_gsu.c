#include <stdlib.h>

int partition(int *array, int low, int high) {
// TODO 
}

void quick_sort_gsu(int *array, int size) {
// TODO 
}
